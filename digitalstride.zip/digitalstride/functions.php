<?php
/**
 * Digital Stride Theme Functions
 */

define('DS_VERSION', '2.5.0');
define('DS_DIR', get_template_directory());
define('DS_URI', get_template_directory_uri());

// ── Theme Setup ──────────────────────────────────────
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);
    add_theme_support('custom-logo');
    add_theme_support('menus');

    register_nav_menus([
        'primary' => __('Primary Menu', 'digitalstride'),
        'footer'  => __('Footer Menu', 'digitalstride'),
    ]);

    add_image_size('partner-logo', 200, 100, false);
    add_image_size('team-photo', 400, 400, true);
    add_image_size('hero-bg', 1920, 900, true);
    add_image_size('card-thumb', 600, 400, true);
});

// ── Enqueue Assets ───────────────────────────────────
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'google-fonts',
        // Only the weights the theme CSS uses (300, 400, 600, 700).
        'https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400;1,600;1,700&family=Merriweather+Sans:wght@300;400;600;700&display=swap',
        [],
        null
    );
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css', [], '6.5.0');
    wp_enqueue_style('digitalstride-main', ds_asset_url('assets/css/digitalstride-main.min.css'), ['google-fonts', 'font-awesome'], null);
    wp_enqueue_script('digitalstride-main', ds_asset_url('assets/js/main.js'), [], null, true);
});

// ── Faster first paint ───────────────────────────────
// Open the font / icon CDN connections before the stylesheets ask for them.
add_filter('wp_resource_hints', function ($urls, $relation) {
    if ($relation === 'preconnect') {
        $urls[] = 'https://fonts.googleapis.com';
        $urls[] = ['href' => 'https://fonts.gstatic.com', 'crossorigin'];
        $urls[] = ['href' => 'https://cdnjs.cloudflare.com', 'crossorigin'];
    }
    return $urls;
}, 10, 2);

// Font Awesome (~100 KB of CSS) only draws icons, so it must not hold up the
// first paint: load it as a print stylesheet and switch it on once it arrives.
add_filter('style_loader_tag', function ($tag, $handle) {
    if ($handle !== 'font-awesome' || is_admin()) return $tag;
    $async = preg_replace('/media=([\'"])all\1/', 'media="print" onload="this.media=\'all\'"', $tag, 1);
    return $async === $tag ? $tag : $async . '<noscript>' . $tag . '</noscript>';
}, 10, 2);

// ── ACF Local JSON ───────────────────────────────────
// Field groups are defined in /acf-json/*.json (one file per group).
// ACF loads them from there and writes admin edits back to the same
// files, so the field definitions can be edited in the WP admin
// (ACF > Field Groups) or in git. See inc/acf-json-sync.php.
add_filter('acf/settings/save_json', function () {
    return DS_DIR . '/acf-json';
});
add_filter('acf/settings/load_json', function ($paths) {
    $paths[] = DS_DIR . '/acf-json';
    return array_unique($paths);
});
require_once DS_DIR . '/inc/acf-json-sync.php';

// ── ACF Init: Options Pages ──────────────────────────
add_action('acf/init', function () {
    // Options pages
    acf_add_options_page([
        'page_title' => 'Theme Settings',
        'menu_title' => 'Theme Settings',
        'menu_slug'  => 'theme-settings',
        'capability' => 'edit_posts',
        'redirect'   => false,
    ]);
    acf_add_options_sub_page([
        'page_title'  => 'Header & Menu',
        'menu_title'  => 'Header & Menu',
        'parent_slug' => 'theme-settings',
    ]);
    acf_add_options_sub_page([
        'page_title'  => 'Who We Serve Menu',
        'menu_title'  => 'Who We Serve Menu',
        'menu_slug'   => 'acf-options-who-we-serve-menu',
        'parent_slug' => 'theme-settings',
    ]);
    acf_add_options_sub_page([
        'page_title'  => 'Footer Settings',
        'menu_title'  => 'Footer',
        'parent_slug' => 'theme-settings',
    ]);
    acf_add_options_sub_page([
        'page_title'  => 'Global CTA',
        'menu_title'  => 'Global CTA',
        'menu_slug'   => 'acf-options-global-cta',
        'parent_slug' => 'theme-settings',
    ]);
    acf_add_options_sub_page([
        'page_title'  => 'Global Testimonials',
        'menu_title'  => 'Testimonials',
        'menu_slug'   => 'acf-options-global-testimonials',
        'parent_slug' => 'theme-settings',
    ]);
    acf_add_options_sub_page([
        'page_title'  => 'Global Partners',
        'menu_title'  => 'Partners',
        'menu_slug'   => 'acf-options-global-partners',
        'parent_slug' => 'theme-settings',
    ]);
    acf_add_options_sub_page([
        'page_title'  => 'Global Clients',
        'menu_title'  => 'Clients',
        'menu_slug'   => 'acf-options-global-clients',
        'parent_slug' => 'theme-settings',
    ]);
    acf_add_options_sub_page([
        'page_title'  => 'Global Core Values',
        'menu_title'  => 'Core Values',
        'menu_slug'   => 'acf-options-global-core-values',
        'parent_slug' => 'theme-settings',
    ]);
    acf_add_options_sub_page([
        'page_title'  => 'AI Quote Settings',
        'menu_title'  => 'AI Quote',
        'menu_slug'   => 'acf-options-ai-quote',
        'parent_slug' => 'theme-settings',
    ]);
    acf_add_options_sub_page([
        'page_title'  => 'Site Audit Settings',
        'menu_title'  => 'Site Audit',
        'menu_slug'   => 'acf-options-site-audit',
        'parent_slug' => 'theme-settings',
    ]);
});

// ── Disable Gutenberg + classic editor body for pages ─
// Pages are built entirely with ACF flexible content.
// The block editor and classic editor textarea are hidden so
// editors only see the title field + ACF sections below it.
add_filter('use_block_editor_for_post_type', function ($use, $post_type) {
    if ($post_type === 'page') return false;
    return $use;
}, 10, 2);

add_action('init', function () {
    remove_post_type_support('page', 'editor');
});

// ── Includes ─────────────────────────────────────────
require_once DS_DIR . '/inc/helpers.php';
require_once DS_DIR . '/inc/audiences.php';
require_once DS_DIR . '/inc/survey.php';
require_once DS_DIR . '/inc/site-audit.php';
require_once DS_DIR . '/inc/podcast.php';
require_once DS_DIR . '/inc/proposal-templates.php';
require_once DS_DIR . '/inc/aec-landing.php';
require_once DS_DIR . '/inc/home-services.php';
require_once DS_DIR . '/inc/realtors.php';
require_once DS_DIR . '/inc/echos-landing.php';
require_once DS_DIR . '/inc/dsd-leads.php';
require_once DS_DIR . '/inc/referrals.php';
require_once DS_DIR . '/inc/referrals-debug.php'; // TEMPORARY — see file header
require_once DS_DIR . '/inc/dsd-dashboard.php';

// ── Retired: medical receipt reimbursements ──────────
// The reimbursement portal was removed from the theme. Drop the capability
// and role it registered so they don't linger in wp-admin. Stored claims
// (ds_reimbursement posts) and files in uploads/ds-receipts/ are left in
// place on purpose — delete or archive them per your retention policy.
add_action('admin_init', function () {
    if (get_option('ds_reimb_retired')) return;
    $admin = get_role('administrator');
    if ($admin) $admin->remove_cap('ds_manage_reimbursements');
    if (get_role('ds_finance') && !get_users(['role' => 'ds_finance', 'number' => 1, 'fields' => 'ID'])) {
        remove_role('ds_finance');
    }
    update_option('ds_reimb_retired', 1);
});
