<?php
/**
 * Helper: inline an SVG from the media library, or fall back to <img>.
 *
 * Pass an ACF image array (return_format = 'array').
 * For SVG files the raw markup is read from disk, stripped of XML/DOCTYPE
 * declarations, and output inline so CSS fill/filter rules can target paths.
 * Non-SVG files are returned as a normal <img> tag.
 *
 * @param array  $image  ACF image array with 'id', 'url', 'alt', 'mime_type'.
 * @param string $class  Extra classes added to the root <svg> or <img>.
 * @return string
 */
function ds_inline_svg( $image, $class = '' ) {
    if ( empty( $image ) ) return '';

    $mime = $image['mime_type'] ?? '';
    $url  = $image['url']       ?? '';
    $ext  = strtolower( pathinfo( $url, PATHINFO_EXTENSION ) );

    if ( $mime === 'image/svg+xml' || $ext === 'svg' ) {
        $path = ! empty( $image['id'] ) ? get_attached_file( $image['id'] ) : '';

        if ( $path && file_exists( $path ) ) {
            $svg = file_get_contents( $path );

            if ( $svg ) {
                // Remove XML declaration and DOCTYPE
                $svg = preg_replace( '/<\?xml[^?]*\?>\s*/i', '', $svg );
                $svg = preg_replace( '/<!DOCTYPE[^>]*>\s*/i',  '', $svg );
                $svg = trim( $svg );

                // Replace hardcoded fill values with currentColor (preserve fill="none")
                // This lets CSS color/fill rules control the icon tint.
                $svg = preg_replace( '/\sfill="(?!none\b)[^"]*"/',   ' fill="currentColor"', $svg );
                $svg = preg_replace( "/\sfill='(?!none\b)[^']*'/",   " fill='currentColor'", $svg );
                // Strip fill from inline style attributes so they don't override CSS
                $svg = preg_replace( '/\bfill\s*:\s*(?!none\b)[^;}"\']+/i', 'fill:currentColor', $svg );

                // Build class string
                $cls = 'ds-svg' . ( $class ? ' ' . esc_attr( $class ) : '' );

                // Inject class and aria-hidden into the root <svg> tag
                if ( preg_match( '/<svg([^>]*)>/i', $svg, $m ) ) {
                    $attrs = $m[1];
                    // Append to existing class or add new one
                    if ( preg_match( '/class=["\']([^"\']*)["\']/', $attrs, $cm ) ) {
                        $new_attrs = str_replace( $cm[0], 'class="' . esc_attr( $cm[1] ) . ' ' . $cls . '"', $attrs );
                    } else {
                        $new_attrs = $attrs . ' class="' . $cls . '"';
                    }
                    // Add aria-hidden if not present
                    if ( strpos( $new_attrs, 'aria-hidden' ) === false ) {
                        $new_attrs .= ' aria-hidden="true"';
                    }
                    $svg = str_replace( $m[0], '<svg' . $new_attrs . '>', $svg );
                }

                return $svg;
            }
        }
    }

    // Fallback: regular img tag
    $cls_attr = $class ? ' class="' . esc_attr( $class ) . '"' : '';
    return '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( $image['alt'] ?? '' ) . '"' . $cls_attr . '>';
}

/**
 * Helper: render a flexible content layout
 */
function ds_render_flex($field_name = 'page_sections', $post_id = false) {
    if (!have_rows($field_name, $post_id)) return;

    while (have_rows($field_name, $post_id)) {
        the_row();
        $layout = get_row_layout();
        // Sections tagged AEC / Home Services get a wrapper the audience
        // toggle can hide. See inc/audiences.php.
        $wrapped = ds_audience_wrap_open();
        get_template_part('template-parts/flex', $layout);
        ds_audience_wrap_close($wrapped);
    }
}

/**
 * Helper: render global flex sections (from options)
 */
function ds_render_global_cta() {
    ds_render_flex('global_cta_sections', 'option');
}

/**
 * Helper: an icon in the site's blue icon gradient. Uploaded SVGs are
 * inlined and filled with #ds-gradient-blue; otherwise a Font Awesome
 * glyph gets the same gradient clipped to it.
 *
 * @param array|null $upload ACF image array (SVG).
 * @param string     $fa     Font Awesome classes, used when nothing is uploaded.
 * @param string     $class  Extra classes for the wrapper.
 * @return string
 */
function ds_gradient_icon($upload, $fa, $class = '') {
    $class = trim('ds-gradient-icon ' . $class);
    if (!empty($upload['url'])) {
        return '<span class="' . esc_attr($class . ' ds-icon--blue-gradient') . '" aria-hidden="true">' . ds_inline_svg($upload) . '</span>';
    }
    if (!$fa) return '';
    return '<span class="' . esc_attr($class . ' ds-gradient-icon--fa') . '" aria-hidden="true"><i class="' . esc_attr($fa) . '"></i></span>';
}

/**
 * Helper: escape a heading and wrap one phrase of it in the blue text
 * gradient. The phrase is appended when the heading doesn't contain it.
 */
function ds_gradient_heading($heading, $highlight, $class = 'ds-text-gradient') {
    $heading   = (string) $heading;
    $highlight = trim((string) $highlight);
    if ($highlight === '') return esc_html($heading);

    $pos  = stripos($heading, $highlight);
    $wrap = function ($text) use ($class) {
        return '<span class="' . esc_attr($class) . '">' . esc_html($text) . '</span>';
    };
    if ($pos === false) {
        return esc_html(rtrim($heading)) . ($heading !== '' ? ' ' : '') . $wrap($highlight);
    }
    return esc_html(substr($heading, 0, $pos))
        . $wrap(substr($heading, $pos, strlen($highlight)))
        . esc_html(substr($heading, $pos + strlen($highlight)));
}

/**
 * Helper: permalink of the first published page using a page template,
 * or home_url($fallback) when no page uses it yet.
 */
function ds_template_page_url($template, $fallback = '/') {
    $ids = get_posts([
        'post_type'      => 'page',
        'post_status'    => 'publish',
        'meta_key'       => '_wp_page_template',
        'meta_value'     => $template,
        'posts_per_page' => 1,
        'fields'         => 'ids',
        'no_found_rows'  => true,
    ]);
    return $ids ? get_permalink($ids[0]) : home_url($fallback);
}

/**
 * Helper: the "features" repeater of the current flex row as plain arrays,
 * falling back to $defaults when no rows have been added yet.
 *
 * @param array $defaults Rows of ['fa', 'title', 'text'].
 * @return array Rows of ['icon', 'fa', 'title', 'text'].
 */
function ds_promo_features(array $defaults) {
    $rows = [];
    if (have_rows('features')) {
        $i = 0;
        while (have_rows('features')) {
            the_row();
            $row = [
                'icon'  => get_sub_field('icon'),
                'fa'    => trim((string) get_sub_field('icon_fa')) ?: ($defaults[$i]['fa'] ?? 'fa-solid fa-check'),
                'title' => get_sub_field('title'),
                'text'  => get_sub_field('text'),
            ];
            $i++;
            if ($row['title'] || $row['text']) $rows[] = $row;
        }
    }
    if ($rows) return $rows;

    return array_map(function ($row) {
        return ['icon' => null] + $row;
    }, $defaults);
}

/**
 * Helper: build an autoplay-friendly embed URL for a YouTube or Vimeo link.
 *
 * Returns '' when the URL is not a recognised provider, so callers can fall
 * back to treating the value as a direct video file.
 *
 * @param string $url   Video page / share URL.
 * @param array  $args  autoplay, loop, controls, muted booleans.
 * @return string
 */
function ds_video_embed_url( $url, $args = [] ) {
    $url = trim( (string) $url );
    if ( ! $url ) return '';

    $args = wp_parse_args( $args, [
        'autoplay' => true,
        'loop'     => false,
        'controls' => false,
        'muted'    => true,
    ] );

    // YouTube: watch?v=ID, youtu.be/ID, /embed/ID, /shorts/ID
    if ( preg_match( '~(?:youtube(?:-nocookie)?\.com/(?:watch\?(?:.*&)?v=|embed/|shorts/|v/)|youtu\.be/)([A-Za-z0-9_-]{6,})~i', $url, $m ) ) {
        $params = [
            'autoplay'       => $args['autoplay'] ? 1 : 0,
            'mute'           => $args['muted']    ? 1 : 0,
            'controls'       => $args['controls'] ? 1 : 0,
            'loop'           => $args['loop']     ? 1 : 0,
            'playsinline'    => 1,
            'rel'            => 0,
            'modestbranding' => 1,
        ];
        // A single-video loop only works when the video is also its own playlist.
        if ( $args['loop'] ) $params['playlist'] = $m[1];

        return add_query_arg( $params, 'https://www.youtube-nocookie.com/embed/' . $m[1] );
    }

    // Vimeo: vimeo.com/ID, player.vimeo.com/video/ID, optional /HASH for unlisted
    if ( preg_match( '~vimeo\.com/(?:video/)?(\d+)(?:/([A-Za-z0-9]+))?~i', $url, $m ) ) {
        $params = [
            'autoplay'    => $args['autoplay'] ? 1 : 0,
            'muted'       => $args['muted']    ? 1 : 0,
            'controls'    => $args['controls'] ? 1 : 0,
            'loop'        => $args['loop']     ? 1 : 0,
            'playsinline' => 1,
            'title'       => 0,
            'byline'      => 0,
            'portrait'    => 0,
            'dnt'         => 1,
        ];
        if ( ! empty( $m[2] ) ) $params['h'] = $m[2];

        return add_query_arg( $params, 'https://player.vimeo.com/video/' . $m[1] );
    }

    return '';
}

/**
 * Helper: pick the <source type> value a browser should be given.
 *
 * A type the browser does not recognise makes it skip the source without
 * looking at the file, so anything outside the web-native containers is
 * returned as '' and left for the browser to sniff. That matters most for
 * .mov uploads, which WordPress reports as video/quicktime: Chrome and
 * Firefox reject that MIME outright, even when the file inside is H.264.
 *
 * @param string $mime Attachment MIME type.
 * @return string      MIME to declare, or '' to omit the attribute.
 */
function ds_video_source_type( $mime ) {
    $web_native = [ 'video/mp4', 'video/webm', 'video/ogg' ];

    return in_array( strtolower( (string) $mime ), $web_native, true ) ? $mime : '';
}

/**
 * Default hero background, used when a hero has no image of its own.
 */
const DS_HERO_DEFAULT_BG = '/wp-content/uploads/2026/05/Digital-Stride-Schematic-of-Building.png';

/**
 * Helper: hero background as a real <img> instead of a CSS background.
 *
 * The hero image is usually the page's Largest Contentful Paint. As a CSS
 * background the browser only finds it after the stylesheet has loaded, and
 * it always gets the full-size upload. As an <img> it is found in the HTML,
 * fetched first (fetchpriority), and phones pick a smaller size from srcset.
 *
 * @param array|int|string|null $image ACF image array, attachment ID, URL, or empty for the default.
 * @return string <img> markup (already escaped), or '' when there is nothing to show.
 */
function ds_hero_bg_img( $image = null ) {
    $id  = 0;
    $url = '';
    if ( is_array( $image ) ) {
        $id  = (int) ( $image['ID'] ?? $image['id'] ?? 0 );
        $url = $image['url'] ?? '';
    } elseif ( is_numeric( $image ) ) {
        $id = (int) $image;
    } elseif ( is_string( $image ) ) {
        $url = $image;
    }

    if ( ! $id && ! $url ) {
        $url = home_url( DS_HERO_DEFAULT_BG );
        $id  = (int) get_transient( 'ds_hero_default_bg_id' );
        if ( ! $id ) {
            // -1 caches "not in the media library" so the lookup runs once a day at most.
            $id = attachment_url_to_postid( $url ) ?: -1;
            set_transient( 'ds_hero_default_bg_id', $id, DAY_IN_SECONDS );
        }
        $id = max( 0, $id );
    }

    $attrs = [
        'class'         => 'ds-hero__bg',
        'alt'           => '',
        'sizes'         => '100vw',
        'loading'       => 'eager',
        'fetchpriority' => 'high',
        'decoding'      => 'async',
    ];

    if ( $id && wp_attachment_is_image( $id ) ) {
        return wp_get_attachment_image( $id, 'full', false, $attrs );
    }
    if ( ! $url ) return '';

    $html = '<img src="' . esc_url( $url ) . '"';
    unset( $attrs['sizes'] );
    foreach ( $attrs as $name => $value ) {
        $html .= ' ' . $name . '="' . esc_attr( $value ) . '"';
    }
    return $html . '>';
}

/**
 * Helper: normalise one carousel repeater row into a predictable array.
 *
 * Rows saved before video support existed have no 'media_type', so anything
 * that is not explicitly a video is treated as an image.
 *
 * @param array $slide Raw ACF repeater row.
 * @return array|null  ['type' => 'image'|'video-file'|'video-embed', ...] or null when empty.
 */
function ds_carousel_slide( $slide ) {
    if ( empty( $slide ) || ! is_array( $slide ) ) return null;

    $caption = $slide['caption'] ?? '';

    if ( ( $slide['media_type'] ?? 'image' ) !== 'video' ) {
        if ( empty( $slide['image'] ) ) return null;

        return [
            'type'    => 'image',
            'image'   => $slide['image'],
            'caption' => $caption,
        ];
    }

    $autoplay = ! isset( $slide['video_autoplay'] ) || $slide['video_autoplay'];
    $loop     = ! empty( $slide['video_loop'] );
    // Without autoplay nothing would ever start, so controls are forced on.
    $controls = ! empty( $slide['video_controls'] ) || ! $autoplay;
    $poster   = $slide['video_poster'] ?? null;
    $source   = $slide['video_source'] ?? 'file';

    $base = [
        'caption'  => $caption,
        'autoplay' => $autoplay,
        'loop'     => $loop,
        'controls' => $controls,
        'poster'   => ! empty( $poster['url'] ) ? $poster['url'] : '',
    ];

    if ( $source === 'file' && ! empty( $slide['video_file']['url'] ) ) {
        return $base + [
            'type' => 'video-file',
            'url'  => $slide['video_file']['url'],
            'mime' => ds_video_source_type( $slide['video_file']['mime_type'] ?? '' ),
            'alt'  => $slide['video_file']['title'] ?? '',
        ];
    }

    if ( $source === 'url' && ! empty( $slide['video_url'] ) ) {
        $embed = ds_video_embed_url( $slide['video_url'], [
            'autoplay' => $autoplay,
            'loop'     => $loop,
            'controls' => $controls,
        ] );

        if ( $embed ) {
            return $base + [
                'type' => 'video-embed',
                'url'  => $embed,
            ];
        }

        // Not YouTube / Vimeo — assume a directly playable file URL.
        return $base + [
            'type' => 'video-file',
            'url'  => $slide['video_url'],
            'mime' => '',
            'alt'  => '',
        ];
    }

    return null;
}

/**
 * Helper: render the shared hero-style media carousel (images and/or videos).
 *
 * Used by the hero and CTA banner flex layouts so both stay in sync.
 *
 * @param array $slides Rows from a 'carousel_images' repeater.
 * @param array $args   'label' => aria-label, 'nav' => show prev/next + dots,
 *                      'interval' => auto-advance ms for non-video slides.
 * @return void
 */
function ds_render_media_carousel( $slides, $args = [] ) {
    if ( empty( $slides ) || ! is_array( $slides ) ) return;

    $args = wp_parse_args( $args, [
        'label'    => __( 'Media carousel', 'digitalstride' ),
        'nav'      => false,
        'interval' => 5000,
    ] );

    $items = array_values( array_filter( array_map( 'ds_carousel_slide', $slides ) ) );
    if ( ! $items ) return;
    ?>
    <div class="ds-hero__carousel" aria-label="<?php echo esc_attr( $args['label'] ); ?>"
         data-interval="<?php echo (int) $args['interval']; ?>">
        <div class="ds-hero__carousel-track">
            <?php foreach ( $items as $i => $item ) :
                $active = ( $i === 0 );
                // Video slides that play through once drive their own timing.
                $waits  = ( $item['type'] === 'video-file' && $item['autoplay'] && ! $item['loop'] );
                ?>
                <div class="ds-hero__slide ds-hero__slide--<?php echo esc_attr( $item['type'] === 'image' ? 'image' : 'video' ); ?> <?php echo $active ? 'is-active' : ''; ?>"
                     aria-hidden="<?php echo $active ? 'false' : 'true'; ?>"
                     <?php echo $waits ? 'data-wait="1"' : ''; ?>>

                    <?php if ( $item['type'] === 'image' ) : ?>
                        <?php
                        $img_id    = (int) ( $item['image']['ID'] ?? 0 );
                        $img_attrs = [
                            'alt'     => $item['image']['alt'] ?: $item['caption'],
                            // Full width when stacked on phones / tablets, a quarter of the hero beside the text.
                            'sizes'   => '(max-width: 1024px) 100vw, 25vw',
                            'loading' => $active ? 'eager' : 'lazy',
                        ];
                        if ( $active ) $img_attrs['fetchpriority'] = 'high';
                        ?>
                        <?php if ( $img_id && wp_attachment_is_image( $img_id ) ) : ?>
                            <?php echo wp_get_attachment_image( $img_id, 'large', false, $img_attrs ); ?>
                        <?php else : ?>
                            <img src="<?php echo esc_url( $item['image']['url'] ); ?>"
                                 alt="<?php echo esc_attr( $img_attrs['alt'] ); ?>"
                                 loading="<?php echo $active ? 'eager' : 'lazy'; ?>">
                        <?php endif; ?>

                    <?php elseif ( $item['type'] === 'video-file' ) : ?>
                        <video class="ds-hero__slide-video"
                               <?php echo $item['poster'] ? 'poster="' . esc_url( $item['poster'] ) . '"' : ''; ?>
                               preload="<?php echo $active ? 'auto' : 'metadata'; ?>"
                               playsinline
                               <?php echo $item['autoplay'] ? 'muted' : ''; ?>
                               <?php echo $item['loop'] ? 'loop' : ''; ?>
                               <?php echo $item['controls'] ? 'controls' : ''; ?>
                               data-autoplay="<?php echo $item['autoplay'] ? '1' : '0'; ?>"
                               <?php echo $item['caption'] ? 'aria-label="' . esc_attr( $item['caption'] ) . '"' : ''; ?>>
                            <source src="<?php echo esc_url( $item['url'] ); ?>"
                                    <?php echo $item['mime'] ? 'type="' . esc_attr( $item['mime'] ) . '"' : ''; ?>>
                        </video>

                    <?php else : ?>
                        <div class="ds-hero__slide-embed">
                            <?php // src is set by JS when the slide becomes active so nothing plays off-screen. ?>
                            <iframe data-src="<?php echo esc_url( $item['url'] ); ?>"
                                    title="<?php echo esc_attr( $item['caption'] ?: __( 'Video', 'digitalstride' ) ); ?>"
                                    frameborder="0" loading="lazy"
                                    allow="autoplay; fullscreen; picture-in-picture; encrypted-media"
                                    allowfullscreen></iframe>
                        </div>
                    <?php endif; ?>

                    <?php if ( $item['caption'] ) : ?>
                        <p class="ds-hero__slide-caption"><?php echo esc_html( $item['caption'] ); ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ( $args['nav'] && count( $items ) > 1 ) : ?>
            <div class="ds-hero__carousel-nav">
                <button class="ds-hero__carousel-btn ds-hero__carousel-btn--prev" aria-label="<?php esc_attr_e( 'Previous slide', 'digitalstride' ); ?>">&#10094;</button>
                <div class="ds-hero__carousel-dots">
                    <?php foreach ( $items as $i => $item ) : ?>
                        <button class="ds-hero__carousel-dot <?php echo $i === 0 ? 'is-active' : ''; ?>"
                                aria-label="<?php printf( esc_attr__( 'Go to slide %d', 'digitalstride' ), $i + 1 ); ?>"
                                data-slide="<?php echo $i; ?>"></button>
                    <?php endforeach; ?>
                </div>
                <button class="ds-hero__carousel-btn ds-hero__carousel-btn--next" aria-label="<?php esc_attr_e( 'Next slide', 'digitalstride' ); ?>">&#10095;</button>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Helper: load Prism syntax highlighting for the Code Snippet layout.
 *
 * Called from the template part, so the assets only load on pages that use
 * it; they print in the footer. The autoloader fetches each language's
 * grammar from the CDN on demand.
 */
function ds_enqueue_code_highlighting() {
    $cdn = 'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0';
    wp_enqueue_style('prism-theme', $cdn . '/themes/prism-tomorrow.min.css', [], '1.29.0');
    wp_enqueue_style('prism-line-numbers', $cdn . '/plugins/line-numbers/prism-line-numbers.min.css', ['prism-theme'], '1.29.0');
    wp_enqueue_script('prism-core', $cdn . '/components/prism-core.min.js', [], '1.29.0', true);
    wp_enqueue_script('prism-autoloader', $cdn . '/plugins/autoloader/prism-autoloader.min.js', ['prism-core'], '1.29.0', true);
    wp_enqueue_script('prism-line-numbers', $cdn . '/plugins/line-numbers/prism-line-numbers.min.js', ['prism-core'], '1.29.0', true);
}

/**
 * Admin: monospace, no-wrap editing for the Custom Code / Code Snippet fields.
 */
add_action('acf/input/admin_head', function () {
    echo '<style>.ds-code-field textarea{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:13px;line-height:1.5;white-space:pre;tab-size:4;}</style>';
});

/**
 * Breadcrumb trail under the header on pages and posts.
 *
 * Currently OFF site-wide (the ds_show_breadcrumbs default is false). To
 * turn it back on everywhere, flip that default to true; to show it on
 * selected pages only, return true from the filter for those pages.
 * ECHO SEO's BreadcrumbList schema is printed separately and is unaffected.
 *
 * Uses ECHO SEO's echs_breadcrumbs() when the plugin is active, so the
 * visible trail matches the BreadcrumbList it prints in the schema graph.
 * Without the plugin the same Home › parents › page trail is rendered here
 * (no schema). Skipped on the front page and Landing Page template (ad
 * landing pages shouldn't offer a way out). The proposal template pages render their
 * own trail.
 */
function ds_breadcrumbs() {
    if (!is_singular() || is_front_page() || is_page_template('page-landing.php')) return;
    if (!apply_filters('ds_show_breadcrumbs', false, get_queried_object_id())) return;

    echo '<div class="ds-breadcrumbs"><div class="ds-container">';
    if (function_exists('echs_breadcrumbs')) {
        echs_breadcrumbs();
    } else {
        $post_id = get_queried_object_id();
        $items   = [['name' => get_bloginfo('name'), 'url' => home_url('/')]];
        foreach (array_reverse(get_post_ancestors($post_id)) as $ancestor_id) {
            $items[] = ['name' => get_the_title($ancestor_id), 'url' => get_permalink($ancestor_id)];
        }
        $items[] = ['name' => get_the_title($post_id), 'url' => ''];

        echo '<nav class="echs-breadcrumbs" aria-label="' . esc_attr__('Breadcrumb', 'digitalstride') . '"><ol>';
        $last = count($items) - 1;
        foreach ($items as $i => $item) {
            echo '<li>';
            if ($item['url'] !== '') {
                echo '<a href="' . esc_url($item['url']) . '">' . esc_html($item['name']) . '</a>';
            } else {
                echo '<span aria-current="page">' . esc_html($item['name']) . '</span>';
            }
            echo '</li>';
            if ($i < $last) echo '<li class="echs-breadcrumb-sep" aria-hidden="true">/</li>';
        }
        echo '</ol></nav>';
    }
    echo '</div></div>';
}

/**
 * Whether the current page is the Services page or an individual service page.
 * Matches the service templates, any page nested under the Services page, and
 * any page linked from the Services mega menu (Theme Settings → Header), so
 * service pages built on the default or landing template are covered too.
 */
function ds_is_service_page() {
    static $result = null;
    if ($result !== null) return $result;
    $result = false;

    if (!is_page() || is_front_page()) return $result;

    if (is_page_template(['page-services.php', 'page-service-overview.php', 'page-service-v1.php', 'page-service-v2.php'])) {
        return $result = true;
    }

    $post_id = get_queried_object_id();
    foreach (get_post_ancestors($post_id) as $ancestor_id) {
        if (get_post_field('post_name', $ancestor_id) === 'services') {
            return $result = true;
        }
    }

    $path_of = function ($url) {
        return trailingslashit('/' . ltrim((string) wp_parse_url($url, PHP_URL_PATH), '/'));
    };
    $current_path = $path_of(get_permalink($post_id));

    $nav_items = function_exists('get_field') ? get_field('nav_items', 'option') : [];
    foreach ((array) $nav_items as $item) {
        $link = $item['link'] ?? null;
        if (!$link) continue;
        $is_services = strcasecmp(trim(wp_strip_all_tags($link['title'])), 'Services') === 0
            || $path_of($link['url']) === $path_of(home_url('/services/'));
        if (!$is_services) continue;

        foreach ((array) ($item['mega_columns'] ?? []) as $column) {
            foreach ((array) ($column['column_links'] ?? []) as $row) {
                if (!empty($row['link']['url']) && $path_of($row['link']['url']) === $current_path) {
                    return $result = true;
                }
            }
        }
    }

    return $result;
}

/**
 * URL for a theme asset whose filename changes whenever the file does.
 *
 * Some caches (host page caches, CDNs, optimisation plugins) ignore the ?ver=
 * query string and keep serving an old main.css / main.js after a deploy. On
 * first use, the file is copied to uploads/ds-assets/<name>.<fingerprint>.<ext>
 * so every change gets a brand-new path that nothing can have cached. Older
 * copies are removed. Falls back to the theme URL (with a ?ver= stamp from the
 * file's mtime and size) if uploads isn't writable.
 * Only use for files without relative url() references.
 *
 * @param string $rel Path relative to the theme root, e.g. 'assets/js/main.js'.
 */
function ds_asset_url($rel) {
    $src      = DS_DIR . '/' . $rel;
    $fallback = DS_URI . '/' . $rel;
    if (!is_readable($src)) return $fallback;
    // If the fingerprinted copy can't be made, still change the URL whenever
    // the file changes so the theme URL isn't served stale from a cache.
    $fallback = add_query_arg('ver', filemtime($src) . '-' . filesize($src), $fallback);

    $uploads = wp_upload_dir(null, false);
    if (!empty($uploads['error'])) return $fallback;

    $info  = pathinfo($rel);
    $base  = sanitize_file_name($info['filename']);
    $ext   = $info['extension'] ?? '';
    $print = substr(md5($rel . '|' . filemtime($src) . '|' . filesize($src)), 0, 12);
    $name  = $base . '.' . $print . '.' . $ext;
    $dir   = trailingslashit($uploads['basedir']) . 'ds-assets';
    $dest  = $dir . '/' . $name;

    if (!file_exists($dest)) {
        if (!wp_mkdir_p($dir) || !@copy($src, $dest)) return $fallback;
        foreach ((array) glob($dir . '/' . $base . '.*.' . $ext) as $old) {
            if ($old !== $dest && preg_match('/\.[0-9a-f]{12}\.' . preg_quote($ext, '/') . '$/', $old)) {
                @unlink($old);
            }
        }
    }

    return set_url_scheme(trailingslashit($uploads['baseurl']) . 'ds-assets/' . $name);
}

/**
 * Sender for the site's emails (referrals, leads, survey, site audit).
 *
 * WordPress sends as "WordPress <wordpress@domain>" unless told otherwise.
 * Only that default is replaced, so an SMTP plugin's own From setting still
 * wins. Override in wp-config.php:
 *   define('DS_MAIL_FROM', 'hello@example.com');
 *   define('DS_MAIL_FROM_NAME', 'Digital Stride');
 * Without DS_MAIL_FROM the admin email (Settings > General) is used, but
 * only when it is on this site's domain: sending as an address on another
 * domain (e.g. Gmail) fails SPF/DMARC and lands in spam.
 */
function ds_mail_from_address() {
    if (defined('DS_MAIL_FROM') && is_email(DS_MAIL_FROM)) return DS_MAIL_FROM;
    $admin = get_option('admin_email');
    $host  = strtolower(preg_replace('/^www\./i', '', (string) wp_parse_url(home_url(), PHP_URL_HOST)));
    $at    = strtolower(substr(strrchr((string) $admin, '@'), 1));
    if (is_email($admin) && $host && ($at === $host || substr($host, -strlen('.' . $at)) === '.' . $at)) return $admin;
    return '';
}

add_filter('wp_mail_from', function ($from) {
    if (stripos((string) $from, 'wordpress@') !== 0) return $from; // already set by a plugin or header
    return ds_mail_from_address() ?: $from;
}, 20);

add_filter('wp_mail_from_name', function ($name) {
    if ($name !== 'WordPress') return $name;
    if (defined('DS_MAIL_FROM_NAME') && DS_MAIL_FROM_NAME) return DS_MAIL_FROM_NAME;
    return wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES) ?: $name;
}, 20);
