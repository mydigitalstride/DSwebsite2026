(function () {
    'use strict';

    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var uidCounter = 0;
    function ensureId(el, prefix) {
        if (!el.id) el.id = prefix + '-' + (++uidCounter);
        return el.id;
    }

    // Hide an off-screen slide from assistive tech AND the tab order.
    function setSlideHidden(slide, hidden) {
        slide.setAttribute('aria-hidden', hidden ? 'true' : 'false');
        slide.inert = hidden;
    }
    document.querySelectorAll('[class*="__slide"][aria-hidden="true"]').forEach(function (s) { s.inert = true; });

    function markDots(dots, index) {
        dots.forEach(function (d, i) {
            if (i === index) d.setAttribute('aria-current', 'true');
            else d.removeAttribute('aria-current');
        });
    }

    /**
     * Autoplay control for carousels (WCAG 2.2.2 Pause, Stop, Hide).
     * Adds a visible pause/play button, pauses while the pointer or keyboard
     * focus is inside, and starts paused when the visitor prefers reduced motion.
     * start()/stop() are the carousel's own timer functions.
     */
    function dsAutoplay(root, start, stop) {
        var userPaused = reduceMotion, hover = false, focus = false, running = false;
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'ds-autoplay-toggle';

        function sync() {
            var should = !userPaused && !hover && !focus;
            if (should && !running) { running = true; start(); }
            else if (!should && running) { running = false; stop(); }
            btn.setAttribute('aria-label', userPaused ? 'Play slideshow' : 'Pause slideshow');
            btn.innerHTML = '<i class="fa-solid ' + (userPaused ? 'fa-play' : 'fa-pause') + '" aria-hidden="true"></i>';
        }

        btn.addEventListener('click', function () { userPaused = !userPaused; sync(); });
        root.addEventListener('mouseenter', function () { hover = true; sync(); });
        root.addEventListener('mouseleave', function () { hover = false; sync(); });
        root.addEventListener('focusin', function (e) {
            if (e.target === btn) return;
            focus = true; sync();
        });
        root.addEventListener('focusout', function (e) {
            if (root.contains(e.relatedTarget) && e.relatedTarget !== btn) return;
            focus = false; sync();
        });
        root.appendChild(btn);
        sync();

        return {
            active: function () { return running; },
            restart: function () { if (running) { stop(); start(); } }
        };
    }

    /**
     * Arrow-key navigation for an ARIA tablist (roving tabindex).
     * activate(index) must update aria-selected / tabindex / panels.
     */
    function dsTabKeys(tabs, activate) {
        tabs = Array.prototype.slice.call(tabs);
        tabs.forEach(function (tab, i) {
            tab.addEventListener('keydown', function (e) {
                if (tab.getAttribute('role') !== 'tab') return;
                var to = null;
                if (e.key === 'ArrowRight' || e.key === 'ArrowDown') to = (i + 1) % tabs.length;
                if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') to = (i - 1 + tabs.length) % tabs.length;
                if (e.key === 'Home') to = 0;
                if (e.key === 'End') to = tabs.length - 1;
                if (to === null) return;
                e.preventDefault();
                activate(to);
                tabs[to].focus();
            });
        });
    }

    // Mobile menu toggle
    var hamburger = document.getElementById('ds-hamburger');
    var nav = document.getElementById('ds-nav');
    function setMenu(open) {
        nav.classList.toggle('is-open', open);
        hamburger.classList.toggle('is-active', open);
        hamburger.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    if (hamburger && nav) {
        hamburger.addEventListener('click', function () {
            setMenu(!nav.classList.contains('is-open'));
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && nav.classList.contains('is-open')) {
                setMenu(false);
                hamburger.focus();
            }
        });
    }

    // Mega menu — tap to open on mobile; on desktop it opens on hover or
    // keyboard focus (CSS :focus-within) and Escape dismisses it.
    document.querySelectorAll('.ds-nav__item--mega').forEach(function (item) {
        var link = item.querySelector('.ds-nav__link');
        var menu = item.querySelector('.ds-mega-menu');
        if (!link) return;
        if (menu) link.setAttribute('aria-controls', ensureId(menu, 'ds-mega'));

        function expanded(on) { link.setAttribute('aria-expanded', on ? 'true' : 'false'); }

        link.addEventListener('click', function (e) {
            if (window.innerWidth <= 1024) {
                e.preventDefault();
                expanded(item.classList.toggle('is-open'));
            }
        });
        item.addEventListener('mouseenter', function () { item.classList.remove('is-dismissed'); expanded(true); });
        item.addEventListener('mouseleave', function () { if (!item.contains(document.activeElement)) expanded(false); });
        item.addEventListener('focusin', function () { if (!item.classList.contains('is-dismissed')) expanded(true); });
        item.addEventListener('focusout', function (e) {
            if (item.contains(e.relatedTarget)) return;
            item.classList.remove('is-dismissed');
            if (window.innerWidth > 1024) expanded(false);
        });
        item.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape') return;
            item.classList.add('is-dismissed');
            item.classList.remove('is-open');
            expanded(false);
            link.focus();
            e.stopPropagation();
        });
    });

    // Generic accordion (FAQ, etc.)
    document.querySelectorAll('.ds-accordion__header').forEach(function (btn) {
        var body = btn.closest('.ds-accordion__item').querySelector('.ds-accordion__body');
        btn.type = 'button';
        if (body) {
            btn.setAttribute('aria-controls', ensureId(body, 'ds-acc'));
            body.setAttribute('role', 'region');
            body.setAttribute('aria-labelledby', ensureId(btn, 'ds-acc-btn'));
        }
        btn.addEventListener('click', function () {
            var item = this.closest('.ds-accordion__item');
            var isOpen = item.classList.contains('is-active');
            item.parentElement.querySelectorAll('.ds-accordion__item').forEach(function (el) {
                el.classList.remove('is-active');
                el.querySelector('.ds-accordion__header').setAttribute('aria-expanded', 'false');
            });
            if (!isOpen) {
                item.classList.add('is-active');
                this.setAttribute('aria-expanded', 'true');
            }
        });
    });

    // Core values — on desktop, line the accordion's top up with the
    // picture's top. Opening a value grows it downward.
    document.querySelectorAll('.ds-values-layout').forEach(function (layout) {
        var img = layout.querySelector('.ds-values-layout__image img');
        var right = layout.querySelector('.ds-values-layout__right');
        var accordion = right && right.querySelector('.ds-accordion');
        if (!img || !accordion) return;

        function align() {
            if (window.innerWidth <= 1024) {
                right.style.paddingTop = '';
                return;
            }
            var top = layout.getBoundingClientRect().top;
            right.style.paddingTop = Math.max(0, img.getBoundingClientRect().top - top) + 'px';
        }

        if (img.complete) align(); else img.addEventListener('load', align);
        window.addEventListener('resize', align);
        if (document.fonts && document.fonts.ready) document.fonts.ready.then(align);
    });

    // Services split — desktop tabs + mobile accordion
    document.querySelectorAll('.ds-services-split').forEach(function (split) {
        var items = split.querySelectorAll('.ds-services-split__item');
        var panels = split.querySelectorAll('.ds-services-split__panel');
        var isMobile = function () { return window.innerWidth <= 1024; };

        function closeAll() {
            items.forEach(function (el) {
                el.classList.remove('is-active');
                el.querySelector('.ds-services-split__header').setAttribute('aria-expanded', 'false');
            });
            panels.forEach(function (el) { el.classList.remove('is-active'); });
            split.classList.remove('is-open');
        }

        // Desktop starts closed with the titles centered; opening one slides the
        // titles left and reveals its panel. Clicking the open title closes it.
        function desktopToggle(index) {
            var wasOpen = items[index].classList.contains('is-active');
            closeAll();
            if (wasOpen) return;
            split.classList.add('is-open');
            items[index].classList.add('is-active');
            items[index].querySelector('.ds-services-split__header').setAttribute('aria-expanded', 'true');
            if (panels[index]) panels[index].classList.add('is-active');
        }

        function mobileToggle(index) {
            var item = items[index];
            var isOpen = item.classList.contains('is-active');
            items.forEach(function (el) {
                el.classList.remove('is-active');
                el.querySelector('.ds-services-split__header').setAttribute('aria-expanded', 'false');
            });
            if (!isOpen) {
                item.classList.add('is-active');
                item.querySelector('.ds-services-split__header').setAttribute('aria-expanded', 'true');
            }
        }

        items.forEach(function (item, i) {
            item.querySelector('.ds-services-split__header').addEventListener('click', function () {
                if (isMobile()) {
                    mobileToggle(i);
                } else {
                    desktopToggle(i);
                }
            });
        });

        // Crossing the mobile/desktop breakpoint resets to the closed state.
        var wasMobile = isMobile();
        function handleResize() {
            if (isMobile() !== wasMobile) {
                wasMobile = isMobile();
                closeAll();
            }
        }

        window.addEventListener('resize', handleResize);
    });

    // Full-Width Angled Carousel
    window.initFwCarousel = function (el, slides) {
        if (!el || !slides.length) return;

        var panels  = el.querySelectorAll('.ds-fwc__panel');
        var imgLeft  = panels[0].querySelector('.ds-fwc__img');
        var imgCenter = panels[1].querySelector('.ds-fwc__img');
        var imgRight  = panels[2].querySelector('.ds-fwc__img');
        var dots    = el.querySelectorAll('.ds-fwc__dot');
        var current = 0;
        var n       = slides.length;
        var timer;

        function idx(i) { return (i + n) % n; }

        function setImg(imgEl, slide) {
            if (!slide || !slide.src) { imgEl.src = ''; return; }
            if (imgEl.src === slide.src) return;
            imgEl.classList.add('is-loading');
            imgEl.onload = function () { imgEl.classList.remove('is-loading'); };
            imgEl.src  = slide.src;
            imgEl.alt  = slide.alt || '';
        }

        function render() {
            setImg(imgLeft,   slides[idx(current - 1)]);
            setImg(imgCenter, slides[idx(current)]);
            setImg(imgRight,  slides[idx(current + 1)]);
            dots.forEach(function (d, i) {
                d.classList.toggle('is-active', i === current);
            });
            markDots(dots, current);
        }

        function goTo(i) {
            current = idx(i);
            render();
        }

        function next() { goTo(current + 1); }

        function startAuto() {
            if (n > 1) timer = setInterval(next, 5000);
        }
        function stopAuto() { clearInterval(timer); }
        var autoplay;
        function resetAuto() { if (autoplay) autoplay.restart(); }

        dots.forEach(function (d) {
            d.addEventListener('click', function () {
                goTo(parseInt(this.dataset.index, 10));
                resetAuto();
            });
        });

        // Swipe support
        var touchStartX = 0;
        el.addEventListener('touchstart', function (e) { touchStartX = e.touches[0].clientX; }, { passive: true });
        el.addEventListener('touchend', function (e) {
            var dx = e.changedTouches[0].clientX - touchStartX;
            if (Math.abs(dx) > 50) { goTo(current + (dx < 0 ? 1 : -1)); resetAuto(); }
        });

        render();
        if (n > 1) autoplay = dsAutoplay(el, startAuto, stopAuto);
    };
    document.dispatchEvent(new CustomEvent('ds:fwc-ready'));

    // Generic fade carousel factory — used by project carousel and testimonial carousel
    function initFadeCarousel(selector, autoInterval) {
        document.querySelectorAll(selector).forEach(function (wrap) {
            var slides = wrap.querySelectorAll('[class$="__slide"], [class*="__slide "]');
            var dots   = wrap.querySelectorAll('[class$="__dot"], [class*="__dot "]');
            var prev   = wrap.querySelector('[class$="__btn--prev"], [class*="__btn--prev"]');
            var next   = wrap.querySelector('[class$="__btn--next"], [class*="__btn--next"]');
            var current = 0;
            var timer;

            if (!slides.length) return;

            function goTo(index) {
                slides[current].classList.remove('is-active');
                setSlideHidden(slides[current], true);
                if (dots.length) dots[current].classList.remove('is-active');
                current = (index + slides.length) % slides.length;
                slides[current].classList.add('is-active');
                setSlideHidden(slides[current], false);
                if (dots.length) dots[current].classList.add('is-active');
                markDots(dots, current);
            }

            var autoplay;
            function startAuto() { timer = setInterval(function () { goTo(current + 1); }, autoInterval); }
            function stopAuto() { clearInterval(timer); }
            function resetAuto() { if (autoplay) autoplay.restart(); }
            markDots(dots, current);

            if (prev) prev.addEventListener('click', function () { goTo(current - 1); resetAuto(); });
            if (next) next.addEventListener('click', function () { goTo(current + 1); resetAuto(); });
            dots.forEach(function (dot) {
                dot.addEventListener('click', function () { goTo(parseInt(this.dataset.slide, 10)); resetAuto(); });
            });

            if (autoInterval && slides.length > 1) autoplay = dsAutoplay(wrap, startAuto, stopAuto);
        });
    }

    initFadeCarousel('.ds-project-carousel', 6000);
    initFadeCarousel('.ds-testimonial-carousel', 7000);
    initFadeCarousel('.ds-portfolio-carousel', 8000);

    // Pricing Feature Table — tab switcher
    document.querySelectorAll('.ds-section--pft').forEach(function (section) {
        var tabs   = section.querySelectorAll('.ds-pft__tab');
        var panels = section.querySelectorAll('.ds-pft__panel');
        tabs.forEach(function (tab, i) {
            tab.addEventListener('click', function () {
                tabs.forEach(function (t) { t.classList.remove('is-active'); t.setAttribute('aria-selected', 'false'); t.tabIndex = -1; });
                panels.forEach(function (p) { p.classList.remove('is-active'); p.setAttribute('aria-hidden', 'true'); });
                tab.classList.add('is-active');
                tab.setAttribute('aria-selected', 'true');
                tab.tabIndex = 0;
                if (panels[i]) { panels[i].classList.add('is-active'); panels[i].setAttribute('aria-hidden', 'false'); }
            });
        });
        dsTabKeys(tabs, function (i) { tabs[i].click(); });
    });

    // Pricing Stack — rotating 3-card perspective carousel
    var STACK_DURATION = 1100;
    var STACK_EASE = STACK_DURATION + 'ms cubic-bezier(0.16, 1, 0.3, 1)';
    var STYLE_ACTIVE = {
        background: 'linear-gradient(135deg, #0993BF 0%, #051879 100%)',
        color:      'white',
        transform:  'scale(1.1)',
        zIndex:     '10',
        opacity:    '1',
        margin:     '0 -60px',
        boxShadow:  '0 25px 60px rgba(0,0,0,0.5)'
    };
    var STYLE_SIDE = {
        background: '#F2F5FB',
        color:      '#020B24',
        transform:  'scale(0.85)',
        zIndex:     '1',
        opacity:    '0.7',
        margin:     '0',
        boxShadow:  '0 20px 50px rgba(0,0,0,0.3)'
    };

    function buildCardHTML(data) {
        return '<h3 class="josefin">' + data.title + '</h3>' +
            '<p class="desc merriweather">' + data.desc + '</p>' +
            '<div class="services merriweather"><strong class="josefin">' + data.servicesLabel + '</strong>' +
            '<ul>' + data.services.map(function(s){ return '<li>' + s + '</li>'; }).join('') + '</ul></div>' +
            '<p class="price merriweather">' + data.price + '</p>' +
            '<button class="btn-orange josefin" onclick="window.location.href=\'' + data.btnLink + '\';event.stopPropagation();">' + data.btnText + '</button>';
    }

    function applyStackStyle(el, isActive, withTrans) {
        var t = withTrans ? ['transform','opacity','margin','box-shadow','background'].map(function(p){ return p + ' ' + STACK_EASE; }).join(', ') : 'none';
        el.style.transition = t;
        var s = isActive ? STYLE_ACTIVE : STYLE_SIDE;
        Object.keys(s).forEach(function(k){ el.style[k] = s[k]; });
        var h3 = el.querySelector('h3');
        if (h3) h3.style.color = isActive ? 'white' : '#020B24';
    }

    window.initPricingStack = function (stackId, mobileId, allCards) {
        var stackEl  = document.getElementById(stackId);
        var mobileEl = document.getElementById(mobileId);
        if (!stackEl || !allCards.length) return;

        var activeIndex = Math.floor(allCards.length / 2);
        var isAnimating = false;
        var slots = [];

        // Build 3 slot elements
        stackEl.innerHTML = '';
        for (var i = 0; i < 3; i++) {
            var card = document.createElement('div');
            card.className = 'price-card';
            stackEl.appendChild(card);
            slots.push(card);
        }

        function getIndices() {
            var n = allCards.length;
            return [(activeIndex - 1 + n) % n, activeIndex, (activeIndex + 1) % n];
        }

        function populate() {
            var idx = getIndices();
            slots.forEach(function (el, i) {
                el.innerHTML = buildCardHTML(allCards[idx[i]]);
                applyStackStyle(el, i === 1, false);
            });
            attachClicks();
        }

        function attachClicks() {
            slots[0].onclick = function (e) { if (e.target.tagName !== 'BUTTON' && !isAnimating) rotate(-1); };
            slots[1].onclick = null;
            slots[2].onclick = function (e) { if (e.target.tagName !== 'BUTTON' && !isAnimating) rotate(1); };
        }

        function rotate(dir) {
            isAnimating = true;
            var movingIdx = dir === 1 ? 2 : 0;
            slots[movingIdx].style.zIndex = '20';
            var trans = ['transform','opacity','margin','box-shadow','background'].map(function(p){ return p + ' ' + STACK_EASE; }).join(', ');
            requestAnimationFrame(function(){ requestAnimationFrame(function(){
                [slots[1], slots[movingIdx]].forEach(function(el, i){
                    el.style.transition = trans;
                    var active = i === 1;
                    var s = active ? STYLE_ACTIVE : STYLE_SIDE;
                    Object.keys(s).forEach(function(k){ el.style[k] = s[k]; });
                    var h3 = el.querySelector('h3');
                    if (h3) h3.style.color = active ? 'white' : '#020B24';
                });
            }); });
            setTimeout(function () {
                activeIndex = (activeIndex + dir + allCards.length) % allCards.length;
                populate();
                isAnimating = false;
            }, STACK_DURATION + 100);
        }

        populate();

        // Mobile
        if (!mobileEl) return;
        var mobileActive = activeIndex;
        function renderMobile() {
            mobileEl.innerHTML = '';
            var tabBar = document.createElement('div');
            tabBar.className = 'mobile-tabs';
            allCards.forEach(function (data, i) {
                var tab = document.createElement('button');
                tab.className = 'mobile-tab josefin' + (i === mobileActive ? ' active' : '');
                tab.textContent = data.title;
                tab.onclick = function () { mobileActive = i; renderMobile(); };
                tabBar.appendChild(tab);
            });
            mobileEl.appendChild(tabBar);
            var data = allCards[mobileActive];
            var card = document.createElement('div');
            card.className = 'mobile-card';
            card.innerHTML = '<h3>' + data.title + '</h3>' +
                '<p class="desc">' + data.desc + '</p>' +
                '<div class="services"><strong>' + data.servicesLabel + '</strong>' +
                '<ul>' + data.services.map(function(s){ return '<li>' + s + '</li>'; }).join('') + '</ul></div>' +
                '<p class="price">' + data.price + '</p>' +
                '<button class="btn-orange" onclick="window.location.href=\'' + data.btnLink + '\'">' + data.btnText + '</button>';
            mobileEl.appendChild(card);
        }
        renderMobile();
    };

    document.dispatchEvent(new CustomEvent('ds:pricing-stack-ready'));

    // Industry Tabs — desktop tabs + mobile accordion
    document.querySelectorAll('.ds-industry-tabs').forEach(function (widget) {
        var tabs   = widget.querySelectorAll('.ds-industry-tabs__tab');
        var panels = widget.querySelectorAll('.ds-industry-tabs__panel');
        var mobilePanels = widget.querySelectorAll('.ds-industry-tabs__mobile-panel');
        var isMobile = function () { return window.innerWidth <= 768; };

        var list = widget.querySelector('.ds-industry-tabs__list');

        // Desktop is an ARIA tablist; on mobile the same buttons are
        // accordion toggles, so swap the roles to match what they do.
        function applyMode() {
            var mobile = isMobile();
            if (list) {
                if (mobile) list.removeAttribute('role'); else list.setAttribute('role', 'tablist');
            }
            tabs.forEach(function (t, i) {
                if (mobile) {
                    t.removeAttribute('role');
                    t.removeAttribute('aria-selected');
                    t.tabIndex = 0;
                    t.setAttribute('aria-controls', ensureId(mobilePanels[i], 'ds-industry-mobile'));
                    t.setAttribute('aria-expanded', mobilePanels[i].classList.contains('is-active') ? 'true' : 'false');
                } else {
                    t.setAttribute('role', 'tab');
                    t.removeAttribute('aria-expanded');
                    if (panels[i]) t.setAttribute('aria-controls', panels[i].id);
                }
            });
        }

        function activateDesktop(index) {
            tabs.forEach(function (t, i) {
                t.classList.toggle('is-active', i === index);
                t.setAttribute('aria-selected', i === index ? 'true' : 'false');
                t.tabIndex = i === index ? 0 : -1;
            });
            panels.forEach(function (p, i) {
                p.classList.toggle('is-active', i === index);
                p.setAttribute('aria-hidden', i === index ? 'false' : 'true');
            });
        }

        function toggleMobile(index) {
            var isOpen = mobilePanels[index].classList.contains('is-active');
            tabs.forEach(function (t) { t.classList.remove('is-active'); });
            mobilePanels.forEach(function (p) { p.classList.remove('is-active'); });
            if (!isOpen) {
                tabs[index].classList.add('is-active');
                mobilePanels[index].classList.add('is-active');
            }
            tabs.forEach(function (t, i) { t.setAttribute('aria-expanded', i === index && !isOpen ? 'true' : 'false'); });
        }

        tabs.forEach(function (tab, i) {
            tab.addEventListener('click', function () {
                if (isMobile()) { toggleMobile(i); } else { activateDesktop(i); }
            });
        });

        dsTabKeys(tabs, activateDesktop);
        applyMode();

        var wasMobile = isMobile();
        window.addEventListener('resize', function () {
            if (isMobile() === wasMobile) return;
            wasMobile = isMobile();
            if (!wasMobile) { activateDesktop(0); }
            applyMode();
        });
    });

    // Mega menu top — dynamically measured from header's actual bottom position.
    // Accounts for WP admin bar (32px desktop / 46px mobile) and any other offsets.
    var header = document.getElementById('ds-header');
    function updateMegaTop() {
        if (!header) return;
        var bottom = header.getBoundingClientRect().bottom + window.scrollY;
        // Use scrollY so the value stays correct when the page is scrolled.
        // For a fixed header this equals the header's rendered bottom from the viewport top.
        var viewportBottom = header.getBoundingClientRect().bottom;
        document.documentElement.style.setProperty('--ds-mega-top', Math.round(viewportBottom-28) + 'px');
    }
    updateMegaTop();
    window.addEventListener('resize', updateMegaTop);
    window.addEventListener('scroll', updateMegaTop);

    // Header shadow on scroll
    if (header) {
        window.addEventListener('scroll', function () {
            header.style.boxShadow = window.scrollY > 10 ? '0 2px 20px rgba(0,0,0,0.3)' : 'none';
        });
    }

    // Hero carousel — supports image, uploaded-video and embedded-video slides
    document.querySelectorAll('.ds-hero__carousel').forEach(function (carousel) {
        var slides = carousel.querySelectorAll('.ds-hero__slide');
        if (!slides.length) return;

        var dots = carousel.querySelectorAll('.ds-hero__carousel-dot');
        var prevBtn = carousel.querySelector('.ds-hero__carousel-btn--prev');
        var nextBtn = carousel.querySelector('.ds-hero__carousel-btn--next');
        var interval = parseInt(carousel.dataset.interval, 10) || 5000;
        var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        var current = 0;
        var timer;

        // Visitors who ask for reduced motion get a paused video with controls,
        // and the carousel keeps to its normal timer instead of waiting on playback.
        if (reduceMotion) {
            slides.forEach(function (slide) {
                slide.dataset.wait = '0';
                var video = slide.querySelector('video');
                if (video) {
                    video.dataset.autoplay = '0';
                    video.controls = true;
                }
                var frame = slide.querySelector('iframe[data-src]');
                if (frame) frame.dataset.src = frame.dataset.src.replace(/([?&])autoplay=1/, '$1autoplay=0');
            });
        }

        // Stop whatever is playing so audio/bandwidth never runs on a hidden slide.
        function stopMedia(slide) {
            var video = slide.querySelector('video');
            if (video) {
                video.pause();
                try { video.currentTime = 0; } catch (e) {}
            }
            var frame = slide.querySelector('iframe[data-src]');
            if (frame && frame.getAttribute('src')) frame.removeAttribute('src');
        }

        function startMedia(slide) {
            var video = slide.querySelector('video');
            if (video) {
                video.preload = 'auto';
                if (video.dataset.autoplay === '1') {
                    var attempt = video.play();
                    if (attempt && attempt.catch) {
                        attempt.catch(function () {
                            // Some browsers only honour autoplay once muted is set in script.
                            video.muted = true;
                            var retry = video.play();
                            if (retry && retry.catch) {
                                retry.catch(function () {
                                    if (video.error) {
                                        markUnplayable(slide, video);
                                        return;
                                    }
                                    // Autoplay refused (e.g. low power mode) — let the
                                    // visitor start it and fall back to the timer.
                                    slide.dataset.wait = '0';
                                    video.controls = true;
                                    if (slide === slides[current]) schedule();
                                });
                            }
                        });
                    }
                }
            }
            // Embeds only get their src once visible, so they load and play on cue.
            var frame = slide.querySelector('iframe[data-src]');
            if (frame) frame.setAttribute('src', frame.dataset.src);
        }

        // A source the browser can't decode (a .mov in Chrome, say) must not stall
        // the rotation or leave a black rectangle where the slide should be.
        function markUnplayable(slide, video) {
            if (slide.classList.contains('is-media-error')) return;
            slide.classList.add('is-media-error');
            slide.dataset.wait = '0';
            video.controls = false;
            if (slide === slides[current]) schedule();
        }

        // Slides marked data-wait play through and advance on 'ended' instead of on a timer.
        var autoplay;
        function schedule() {
            clearTimeout(timer);
            if (slides.length < 2) return;
            if (autoplay && !autoplay.active()) return;
            if (slides[current].dataset.wait === '1') return;
            timer = setTimeout(function () { goTo(current + 1); }, interval);
        }

        function goTo(index) {
            var next = (index + slides.length) % slides.length;
            if (next === current) return;

            slides[current].classList.remove('is-active');
            setSlideHidden(slides[current], true);
            if (dots.length) dots[current].classList.remove('is-active');
            stopMedia(slides[current]);

            current = next;
            slides[current].classList.add('is-active');
            setSlideHidden(slides[current], false);
            if (dots.length) dots[current].classList.add('is-active');
            markDots(dots, current);
            startMedia(slides[current]);

            schedule();
        }

        slides.forEach(function (slide, i) {
            var video = slide.querySelector('video');
            if (!video) return;

            video.addEventListener('ended', function () {
                if (i === current && slide.dataset.wait === '1') goTo(current + 1);
            });
            video.addEventListener('error', function () {
                markUnplayable(slide, video);
            });
        });

        startMedia(slides[current]);

        if (slides.length > 1) {
            if (prevBtn) prevBtn.addEventListener('click', function () { goTo(current - 1); });
            if (nextBtn) nextBtn.addEventListener('click', function () { goTo(current + 1); });
            dots.forEach(function (dot) {
                dot.addEventListener('click', function () { goTo(parseInt(this.dataset.slide, 10)); });
            });
            markDots(dots, current);
            autoplay = dsAutoplay(carousel, schedule, function () { clearTimeout(timer); });
        }
    });

    // Logo carousel — auto-scrolling with center-scale effect
    document.querySelectorAll('.ds-logo-carousel').forEach(function (carousel) {
        var track = carousel.querySelector('.ds-logo-carousel__track');
        var slides = track.querySelectorAll('.ds-logo-carousel__slide');
        if (slides.length < 3) return;

        var current = 0;
        var slideWidth = 0;
        var visibleCount = 5;
        var timer;

        function measure() {
            slideWidth = slides[0].offsetWidth;
            visibleCount = Math.round(carousel.offsetWidth / slideWidth);
        }

        function updateClasses() {
            var centerIndex = Math.floor(visibleCount / 2);
            slides.forEach(function (s) {
                s.classList.remove('is-center', 'is-adjacent');
            });
            var ci = current + centerIndex;
            if (ci < slides.length) slides[ci].classList.add('is-center');
            if (ci - 1 >= 0 && ci - 1 < slides.length) slides[ci - 1].classList.add('is-adjacent');
            if (ci + 1 < slides.length) slides[ci + 1].classList.add('is-adjacent');
        }

        function advance() {
            current++;
            if (current > slides.length - visibleCount) {
                current = 0;
                track.style.transition = 'none';
                track.style.transform = 'translateX(0)';
                track.offsetHeight;
                track.style.transition = 'transform 0.5s ease';
            }
            track.style.transform = 'translateX(-' + (current * slideWidth) + 'px)';
            updateClasses();
        }

        function start() {
            timer = setInterval(advance, 3000);
        }

        measure();
        updateClasses();

        window.addEventListener('resize', function () {
            measure();
            track.style.transform = 'translateX(-' + (current * slideWidth) + 'px)';
            updateClasses();
        });

        dsAutoplay(carousel, start, function () { clearInterval(timer); });
    });

    // Gallery lightbox
    (function () {
        var lightbox  = document.getElementById('ds-lightbox');
        if (!lightbox) return;
        var lbImg     = lightbox.querySelector('.ds-lightbox__img');
        var lbCap     = lightbox.querySelector('.ds-lightbox__caption');
        var closeBtn  = lightbox.querySelector('.ds-lightbox__close');
        var prevBtn   = lightbox.querySelector('.ds-lightbox__prev');
        var nextBtn   = lightbox.querySelector('.ds-lightbox__next');
        var items     = [];
        var current   = 0;

        function collect() {
            items = Array.from(document.querySelectorAll('.ds-gallery__lightbox'));
        }

        var returnFocus = null;

        function open(index) {
            collect();
            current = index;
            show(current);
            returnFocus = document.activeElement;
            lightbox.classList.add('is-open');
            lightbox.setAttribute('aria-hidden', 'false');
            document.body.style.overflow = 'hidden';
            closeBtn.focus();
        }

        function close() {
            lightbox.classList.remove('is-open');
            lightbox.setAttribute('aria-hidden', 'true');
            document.body.style.overflow = '';
            if (returnFocus && returnFocus.focus) returnFocus.focus();
        }

        function show(index) {
            var el  = items[index];
            var img = el.querySelector('img');
            lbImg.src = el.href;
            lbImg.alt = img ? img.alt : '';
            lbCap.textContent = el.dataset.caption || '';
            prevBtn.style.display = items.length > 1 ? '' : 'none';
            nextBtn.style.display = items.length > 1 ? '' : 'none';
        }

        document.addEventListener('click', function (e) {
            var link = e.target.closest('.ds-gallery__lightbox');
            if (!link) return;
            e.preventDefault();
            collect();
            open(items.indexOf(link));
        });

        closeBtn.addEventListener('click', close);
        lightbox.addEventListener('click', function (e) { if (e.target === lightbox) close(); });
        prevBtn.addEventListener('click', function () { current = (current - 1 + items.length) % items.length; show(current); });
        nextBtn.addEventListener('click', function () { current = (current + 1) % items.length; show(current); });
        document.addEventListener('keydown', function (e) {
            if (!lightbox.classList.contains('is-open')) return;
            if (e.key === 'Escape') close();
            if (e.key === 'Tab') {
                // Keep keyboard focus inside the open dialog.
                var f = Array.prototype.filter.call(lightbox.querySelectorAll('button'), function (b) { return b.offsetParent !== null; });
                if (!f.length) return;
                var first = f[0], last = f[f.length - 1];
                if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
                else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
                else if (!lightbox.contains(document.activeElement)) { e.preventDefault(); first.focus(); }
            }
            if (e.key === 'ArrowLeft') { current = (current - 1 + items.length) % items.length; show(current); }
            if (e.key === 'ArrowRight') { current = (current + 1) % items.length; show(current); }
        });
    })();

    // Marketing Needs Survey — multi-step form with conditional routing
    document.querySelectorAll('.ds-survey').forEach(function (survey) {
        var form      = survey.querySelector('.ds-survey__form');
        var steps     = Array.from(survey.querySelectorAll('.ds-survey__step'));
        var backBtn   = survey.querySelector('.ds-survey__back');
        var nextBtn   = survey.querySelector('.ds-survey__next');
        var submitBtn = survey.querySelector('.ds-survey__submit');
        var fill      = survey.querySelector('.ds-survey__progress-fill');
        var progLabel = survey.querySelector('.ds-survey__progress-label');
        var formError = survey.querySelector('.ds-survey__form-error');
        var success   = survey.querySelector('.ds-survey__success');
        var current   = 0;

        if (!form || !steps.length) return;

        function answerFor(name) {
            var values = [];
            form.querySelectorAll('[name="' + name + '"], [name="' + name + '[]"]').forEach(function (input) {
                if (input.type === 'radio' || input.type === 'checkbox') {
                    if (input.checked) values.push(input.value);
                } else if (input.value.trim() !== '') {
                    values.push(input.value.trim());
                }
            });
            return values;
        }

        // Show/hide conditional questions; clear answers of hidden ones.
        function applyConditions() {
            survey.querySelectorAll('.ds-survey__q[data-show-if]').forEach(function (q) {
                var cond = JSON.parse(q.dataset.showIf);
                var met = answerFor(cond.field).some(function (v) {
                    return cond.values.indexOf(v) !== -1;
                });
                q.hidden = !met;
                if (!met) {
                    q.querySelectorAll('input, textarea, select').forEach(function (input) {
                        if (input.type === 'radio' || input.type === 'checkbox') {
                            input.checked = false;
                        } else {
                            input.value = '';
                        }
                    });
                }
            });
        }

        function validateStep(index) {
            var ok = true;
            steps[index].querySelectorAll('.ds-survey__q').forEach(function (q) {
                var error = q.querySelector('.ds-survey__error');
                error.hidden = true;
                q.classList.remove('has-error');
                if (q.hidden || !q.dataset.required) return;

                var answered;
                var input = q.querySelector('.ds-survey__input');
                if (input) {
                    var val = input.value.trim();
                    answered = val !== '';
                    if (answered && input.type === 'email') {
                        answered = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
                    }
                } else {
                    answered = !!q.querySelector('input:checked');
                }

                if (!answered) {
                    ok = false;
                    error.hidden = false;
                    q.classList.add('has-error');
                }
            });
            return ok;
        }

        function show(index) {
            current = index;
            applyConditions();
            steps.forEach(function (step, i) {
                step.classList.toggle('is-active', i === index);
            });
            backBtn.hidden = index === 0;
            nextBtn.hidden = index === steps.length - 1;
            submitBtn.hidden = index !== steps.length - 1;
            fill.style.width = ((index + 1) / steps.length * 100) + '%';
            progLabel.textContent = 'Step ' + (index + 1) + ' of ' + steps.length + ' — ' + steps[index].dataset.stepTitle;
            var top = survey.getBoundingClientRect().top + window.pageYOffset - 120;
            if (window.pageYOffset > top) window.scrollTo({ top: top, behavior: 'smooth' });
        }

        nextBtn.addEventListener('click', function () {
            if (validateStep(current)) show(current + 1);
        });
        backBtn.addEventListener('click', function () { show(current - 1); });

        form.addEventListener('change', function (e) {
            applyConditions();
            // Exclusive checkbox (e.g. "not actively marketing") clears its siblings.
            var target = e.target;
            if (target.type === 'checkbox') {
                var group = target.closest('.ds-survey__options');
                if (!group) return;
                if (target.dataset.exclusive && target.checked) {
                    group.querySelectorAll('input:checked').forEach(function (input) {
                        if (input !== target) input.checked = false;
                    });
                } else if (target.checked) {
                    group.querySelectorAll('input[data-exclusive]').forEach(function (input) {
                        input.checked = false;
                    });
                }
            }
        });

        // Instant gap snapshot rendered into the success panel.
        // Built with createElement/textContent — server strings, but never trust markup.
        function renderAnalysis(analysis) {
            var box = survey.querySelector('.ds-survey__analysis');
            if (!box) return;
            var gaps = analysis.gaps || [];

            var score = document.createElement('div');
            score.className = 'ds-survey__score';
            var num = document.createElement('span');
            num.className = 'ds-survey__score-num';
            num.textContent = analysis.score + '/100';
            var label = document.createElement('span');
            label.className = 'ds-survey__score-label';
            label.textContent = analysis.label;
            score.appendChild(num);
            score.appendChild(label);
            box.appendChild(score);

            if (gaps.length) {
                var heading = document.createElement('h4');
                heading.className = 'ds-survey__analysis-heading';
                heading.textContent = 'What we spotted right away';
                box.appendChild(heading);

                var list = document.createElement('ol');
                list.className = 'ds-survey__gaps';
                gaps.forEach(function (gap) {
                    var item = document.createElement('li');
                    var title = document.createElement('strong');
                    title.textContent = gap.title;
                    var detail = document.createElement('span');
                    detail.textContent = gap.detail;
                    item.appendChild(title);
                    item.appendChild(detail);
                    list.appendChild(item);
                });
                box.appendChild(list);
            }

            var note = document.createElement('p');
            note.className = 'ds-survey__analysis-note';
            note.textContent = gaps.length
                ? "This is our automated first pass based on your answers — we'll go deeper on each of these when we talk."
                : "You've got the fundamentals covered — we'll dig into optimization opportunities when we talk.";
            box.appendChild(note);
            box.hidden = false;
        }

        // AI quote: second request after submit; loading card while Claude works.
        function el(tag, className, text) {
            var node = document.createElement(tag);
            if (className) node.className = className;
            if (text) node.textContent = text;
            return node;
        }

        function fetchQuote(grant) {
            var box = el('div', 'ds-survey__quote');
            var loading = el('div', 'ds-survey__quote-loading');
            loading.appendChild(el('span', 'ds-survey__quote-spinner'));
            loading.appendChild(el('p', '', 'Building your custom plan and preliminary quote…'));
            box.appendChild(loading);
            success.appendChild(box);

            var body = new FormData();
            body.append('action', 'ds_survey_quote');
            body.append('entry', grant.entry);
            body.append('token', grant.token);

            fetch(form.getAttribute('action'), { method: 'POST', body: body })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (!data.success) throw data;
                    box.removeChild(loading);
                    renderQuote(box, data.data.quote);
                })
                .catch(function () {
                    loading.innerHTML = '';
                    loading.appendChild(el('p', 'ds-survey__quote-fallback',
                        "We couldn't build your quote automatically — no problem, we'll include it when we reach out."));
                });
        }

        function renderQuote(box, quote) {
            box.appendChild(el('h4', 'ds-survey__quote-heading', 'Your preliminary game plan'));
            box.appendChild(el('p', 'ds-survey__quote-summary', quote.summary));

            var list = el('div', 'ds-survey__quote-recs');
            (quote.recommendations || []).forEach(function (rec) {
                var card = el('div', 'ds-survey__quote-rec');
                var top = el('div', 'ds-survey__quote-rec-top');
                top.appendChild(el('strong', '', rec.service));
                top.appendChild(el('span', 'ds-survey__quote-price', rec.investment));
                card.appendChild(top);
                card.appendChild(el('p', '', rec.rationale));
                list.appendChild(card);
            });
            box.appendChild(list);

            var total = el('p', 'ds-survey__quote-total');
            total.appendChild(el('span', '', 'Recommended investment: '));
            total.appendChild(el('strong', '', quote.total_monthly_investment));
            box.appendChild(total);

            box.appendChild(el('p', 'ds-survey__quote-outcomes', quote.expected_outcomes));
            box.appendChild(el('p', 'ds-survey__quote-next', quote.next_step));
            box.appendChild(el('p', 'ds-survey__analysis-note',
                'This is a preliminary, AI-assisted estimate based on your answers — your final proposal comes after we talk.'));
        }

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            if (!validateStep(current)) return;
            formError.hidden = true;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Sending…';

            // getAttribute: the "action" ajax field shadows form.action (DOM clobbering)
            fetch(form.getAttribute('action'), { method: 'POST', body: new FormData(form) })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (!data.success) throw data;
                    form.hidden = true;
                    survey.querySelector('.ds-survey__progress').hidden = true;
                    success.hidden = false;
                    if (data.data && data.data.analysis) renderAnalysis(data.data.analysis);
                    if (data.data && data.data.quote) fetchQuote(data.data.quote);
                })
                .catch(function (err) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Get My Assessment';
                    formError.textContent = (err && err.data && err.data.message)
                        ? err.data.message
                        : 'Something went wrong sending your answers. Please try again, or email us directly.';
                    formError.hidden = false;
                });
        });

        show(0);
    });

    // Free Site & AI Search Audit — capture lead, then run Lighthouse + AI checks.
    // See inc/site-audit.php. Server strings are rendered with textContent only.
    document.querySelectorAll('.ds-audit').forEach(function (audit) {
        var form      = audit.querySelector('.ds-audit__form');
        var submitBtn = audit.querySelector('.ds-audit__submit');
        var formError = audit.querySelector('.ds-survey__form-error');
        var loading   = audit.querySelector('.ds-audit__loading');
        var loadText  = audit.querySelector('.ds-audit__loading-text');
        var results   = audit.querySelector('.ds-audit__results');
        var cta       = audit.querySelector('.ds-audit__cta');
        var btnLabel  = submitBtn.textContent;
        var endpoint  = form.getAttribute('action'); // "action" field shadows form.action
        var ticker;

        function el(tag, className, text) {
            var node = document.createElement(tag);
            if (className) node.className = className;
            if (text) node.textContent = text;
            return node;
        }

        function band(score) {
            return score >= 90 ? 'good' : (score >= 50 ? 'ok' : 'poor');
        }

        function validate() {
            var ok = true;
            form.querySelectorAll('.ds-audit__field[data-required]').forEach(function (field) {
                var input = field.querySelector('input');
                var value = input.type === 'checkbox' ? input.checked : input.value.trim() !== '';
                if (value && input.type === 'email') value = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim());
                if (value && field.getAttribute('data-name') === 'website_url') value = /\.[a-z]{2,}/i.test(input.value);
                field.classList.toggle('has-error', !value);
                field.querySelector('.ds-survey__error').hidden = value;
                if (!value && ok) { input.focus(); ok = false; }
            });
            return ok;
        }

        function markFields(names) {
            (names || []).forEach(function (name) {
                var field = form.querySelector('.ds-audit__field[data-name="' + name + '"]');
                if (!field) return;
                field.classList.add('has-error');
                field.querySelector('.ds-survey__error').hidden = false;
            });
        }

        function fail(message) {
            clearInterval(ticker);
            loading.hidden = true;
            form.hidden = false;
            submitBtn.disabled = false;
            submitBtn.textContent = btnLabel;
            formError.textContent = message || 'Something went wrong running your audit. Please try again, or contact us directly.';
            formError.hidden = false;
        }

        function startTicker() {
            var steps = [
                'Running Google Lighthouse on your site…',
                'Measuring mobile speed and Core Web Vitals…',
                'Checking SEO and accessibility…',
                'Checking whether AI crawlers can reach you…',
                'Looking for structured data and llms.txt…',
                'Putting your report together…'
            ];
            var i = 0;
            loadText.textContent = steps[0];
            ticker = setInterval(function () {
                i = Math.min(i + 1, steps.length - 1);
                loadText.textContent = steps[i];
            }, 8000);
        }

        function gauge(label, score, featured) {
            var item = el('div', 'ds-audit__gauge ds-audit__gauge--' + band(score) + (featured ? ' ds-audit__gauge--featured' : ''));
            var ring = el('div', 'ds-audit__ring');
            ring.style.setProperty('--score', score);
            ring.setAttribute('role', 'img');
            ring.setAttribute('aria-label', label + ': ' + score + ' out of 100');
            ring.appendChild(el('span', 'ds-audit__ring-num', String(score)));
            item.appendChild(ring);
            item.appendChild(el('span', 'ds-audit__gauge-label', label));
            return item;
        }

        function render(report) {
            var lh = report.lighthouse || {};
            var scores = lh.scores || {};
            results.innerHTML = '';

            var summary = report.ai_summary;
            if (summary) {
                var card = el('div', 'ds-audit__summary');
                card.appendChild(el('h3', 'ds-audit__headline', summary.headline));
                card.appendChild(el('p', '', summary.summary));
                var fixes = el('ol', 'ds-survey__gaps');
                (summary.top_fixes || []).forEach(function (fix) {
                    var li = el('li');
                    li.appendChild(el('strong', '', fix.title));
                    li.appendChild(el('span', '', fix.why));
                    fixes.appendChild(li);
                });
                card.appendChild(fixes);
                results.appendChild(card);
            }

            var gauges = el('div', 'ds-audit__gauges');
            gauges.appendChild(gauge('AI Search Readiness', report.ai_readiness.score, true));
            ['performance', 'seo', 'accessibility', 'best-practices', 'agentic-browsing'].forEach(function (id) {
                if (scores[id]) gauges.appendChild(gauge(scores[id].title, scores[id].score));
            });
            results.appendChild(gauges);

            if (report.lighthouse_error) {
                results.appendChild(el('p', 'ds-audit__notice', report.lighthouse_error + ' Your AI readiness checks are below, and we will follow up with the rest.'));
            }

            // AI search readiness checklist (our checks + Lighthouse Agentic Browsing audits)
            results.appendChild(el('h3', 'ds-audit__section-title', 'AI search readiness'));
            var checks = el('ul', 'ds-audit__checks');
            var icons = { pass: 'fa-circle-check', warn: 'fa-circle-exclamation', fail: 'fa-circle-xmark' };
            report.ai_readiness.checks.forEach(function (check) {
                var li = el('li', 'ds-audit__check ds-audit__check--' + check.status);
                var icon = el('i', 'fa-solid ' + icons[check.status]);
                icon.setAttribute('aria-hidden', 'true');
                li.appendChild(icon);
                var body = el('div');
                body.appendChild(el('strong', '', check.label));
                body.appendChild(el('span', '', check.detail));
                li.appendChild(body);
                checks.appendChild(li);
            });
            (lh.agentic || []).forEach(function (a) {
                var status = a.passed ? 'pass' : 'fail';
                var li = el('li', 'ds-audit__check ds-audit__check--' + status);
                var icon = el('i', 'fa-solid ' + icons[status]);
                icon.setAttribute('aria-hidden', 'true');
                li.appendChild(icon);
                var body = el('div');
                body.appendChild(el('strong', '', a.title));
                body.appendChild(el('span', '', 'Google Lighthouse agentic browsing check' + (a.detail ? ' — ' + a.detail : '')));
                li.appendChild(body);
                checks.appendChild(li);
            });
            results.appendChild(checks);

            if (lh.metrics && lh.metrics.length) {
                results.appendChild(el('h3', 'ds-audit__section-title', 'Mobile speed'));
                var metrics = el('div', 'ds-audit__metrics');
                lh.metrics.forEach(function (m) {
                    var tile = el('div', 'ds-audit__metric ds-audit__metric--' + (m.score === null ? 'ok' : band(m.score * 100)));
                    tile.appendChild(el('span', 'ds-audit__metric-value', m.value));
                    tile.appendChild(el('span', 'ds-audit__metric-label', m.label));
                    metrics.appendChild(tile);
                });
                results.appendChild(metrics);
            }

            if (lh.opportunities && lh.opportunities.length) {
                results.appendChild(el('h3', 'ds-audit__section-title', 'Top issues Google found'));
                var list = el('ul', 'ds-audit__issues');
                lh.opportunities.forEach(function (o) {
                    var li = el('li');
                    li.appendChild(el('strong', '', o.title));
                    li.appendChild(el('span', '', o.category + (o.detail ? ' · ' + o.detail : '')));
                    list.appendChild(li);
                });
                results.appendChild(list);
            }

            results.appendChild(el('p', 'ds-survey__analysis-note',
                'Scores come from Google Lighthouse' + (lh.lighthouse_version ? ' ' + lh.lighthouse_version : '') +
                ' (mobile, via PageSpeed Insights) and our AI search readiness checks. They measure how well your site is built to be found and understood — not your current rankings. A copy is on its way to your inbox.'));

            loading.hidden = true;
            results.hidden = false;
            if (cta) cta.hidden = false;
            var top = audit.getBoundingClientRect().top + window.pageYOffset - 120;
            window.scrollTo({ top: top, behavior: 'smooth' });
        }

        form.addEventListener('input', function (e) {
            var field = e.target.closest('.ds-audit__field');
            if (field && field.classList.contains('has-error')) {
                field.classList.remove('has-error');
                field.querySelector('.ds-survey__error').hidden = true;
            }
        });

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            formError.hidden = true;
            if (!validate()) return;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Starting…';

            fetch(endpoint, { method: 'POST', body: new FormData(form) })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (!data.success) throw data;
                    form.hidden = true;
                    loading.hidden = false;
                    startTicker();

                    var body = new FormData();
                    body.append('action', 'ds_site_audit_run');
                    body.append('lead', data.data.lead);
                    body.append('token', data.data.token);
                    return fetch(endpoint, { method: 'POST', body: body })
                        .then(function (res) { return res.json(); })
                        .then(function (run) {
                            clearInterval(ticker);
                            if (!run.success) throw run;
                            render(run.data.report);
                        })
                        .catch(function () {
                            // Lead is already saved and the server keeps working if
                            // this request drops, so don't invite a duplicate submit.
                            clearInterval(ticker);
                            loading.querySelector('.ds-survey__quote-spinner').hidden = true;
                            loadText.textContent = "Your audit is taking longer than usual — no problem, we've got your request and will email your report shortly.";
                            loading.querySelector('.ds-audit__loading-note').hidden = true;
                            if (cta) cta.hidden = false;
                        });
                })
                .catch(function (err) {
                    if (err && err.data && err.data.fields) markFields(err.data.fields);
                    fail(err && err.data && err.data.message);
                });
        });
    });

    // Lead form — posts to our server (inc/dsd-leads.php), which forwards the
    // lead to DSD. Without JS the form posts normally and the server redirects back.
    document.querySelectorAll('.ds-lead').forEach(function (wrap) {
        var form      = wrap.querySelector('.ds-lead__form');
        var submitBtn = wrap.querySelector('.ds-lead__submit');
        var formError = wrap.querySelector('.ds-survey__form-error');
        var success   = wrap.querySelector('.ds-lead__success');
        var endpoint  = form.getAttribute('action'); // "action" field shadows form.action
        var btnLabel  = submitBtn.textContent;
        var emailRe   = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        form.noValidate = true; // JS takes over; native validation stays as the no-JS fallback

        function value(name) {
            var input = form.elements[name];
            return input ? input.value.trim() : '';
        }

        function setInvalid(name, invalid) {
            var field = form.querySelector('.ds-lead__field[data-name="' + name + '"]');
            if (!field) return;
            var input = field.querySelector('input, select, textarea');
            field.classList.toggle('has-error', invalid);
            field.querySelector('.ds-survey__error').hidden = !invalid;
            if (invalid) input.setAttribute('aria-invalid', 'true');
            else input.removeAttribute('aria-invalid');
        }

        function focusFirstError() {
            var first = form.querySelector('.ds-lead__field.has-error input, .ds-lead__field.has-error select, .ds-lead__field.has-error textarea');
            if (first) first.focus();
        }

        function validate() {
            var email = value('contact_email');
            var phone = value('contact_phone');
            var bad = {
                contact_name: value('contact_name') === '',
                contact_email: email ? !emailRe.test(email) : phone === '',
                contact_phone: phone !== '' && phone.replace(/\D/g, '').length < 7
            };
            Object.keys(bad).forEach(function (name) { setInvalid(name, bad[name]); });
            focusFirstError();
            return !bad.contact_name && !bad.contact_email && !bad.contact_phone;
        }

        function fail(message) {
            submitBtn.disabled = false;
            submitBtn.textContent = btnLabel;
            formError.textContent = message || "Sorry, something went wrong on our end. Please try again, or call or email us.";
            formError.hidden = false;
        }

        form.addEventListener('input', function (e) {
            var field = e.target.closest('.ds-lead__field');
            if (field && field.classList.contains('has-error')) setInvalid(field.getAttribute('data-name'), false);
        });

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            formError.hidden = true;
            if (!validate()) return;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Sending…';

            var data = new FormData(form);
            data.set('ds_ajax', '1');
            data.set('page_url', window.location.href);
            if (window.MDSAttribution && typeof window.MDSAttribution.get === 'function') {
                try { data.set('mds_attribution', JSON.stringify(window.MDSAttribution.get())); } catch (err) {}
            }

            fetch(endpoint, { method: 'POST', body: data, credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (res) {
                    if (!res.success) throw res;
                    form.hidden = true;
                    success.hidden = false;
                    success.focus();
                    var top = wrap.getBoundingClientRect().top + window.pageYOffset - 120;
                    window.scrollTo({ top: top, behavior: 'smooth' });
                })
                .catch(function (err) {
                    var errors = err && err.data && err.data.errors;
                    if (errors) {
                        Object.keys(errors).forEach(function (name) { setInvalid(name, true); });
                        focusFirstError();
                    }
                    fail(err && err.data && err.data.message);
                });
        });
    });

    // Referral form — the referrer plus one row per person, "Add another person"
    // up to data-max. Saved by inc/referrals.php. Without JS one person posts.
    document.querySelectorAll('.ds-referral').forEach(function (wrap) {
        var form      = wrap.querySelector('.ds-referral__form');
        var people    = wrap.querySelector('.ds-referral__people');
        var tpl       = wrap.querySelector('.ds-referral__template');
        var addBtn    = wrap.querySelector('.ds-referral__add');
        var limitNote = wrap.querySelector('.ds-referral__limit');
        var countEl   = wrap.querySelector('.ds-referral__count');
        var totalEl   = wrap.querySelector('.ds-referral__total');
        var submitBtn = wrap.querySelector('.ds-lead__submit');
        var formError = wrap.querySelector('.ds-survey__form-error');
        var success   = wrap.querySelector('.ds-lead__success');
        var endpoint  = form.getAttribute('action'); // "action" field shadows form.action
        var btnLabel  = submitBtn.textContent;
        var max       = parseInt(wrap.getAttribute('data-max'), 10) || 15;
        var reward    = parseFloat(wrap.getAttribute('data-reward')) || 0;
        var nextIndex = 1; // row indexes only need to be unique, not consecutive
        var emailRe   = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        form.noValidate = true; // JS takes over; native validation stays as the no-JS fallback

        function money(n) {
            return '$' + (n % 1 ? n.toFixed(2) : String(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        }

        function rows() {
            return Array.prototype.slice.call(people.querySelectorAll('.ds-referral__person'));
        }

        // Renumber the rows and refresh the tally / add button.
        function refresh() {
            var list = rows();
            list.forEach(function (row, n) {
                row.querySelector('.ds-referral__person-num').textContent = n + 1;
                var remove = row.querySelector('.ds-referral__remove');
                remove.hidden = list.length === 1;
                remove.setAttribute('aria-label', 'Remove person ' + (n + 1));
            });
            countEl.textContent = list.length;
            totalEl.textContent = money(reward * list.length);
            addBtn.hidden = list.length >= max;
            limitNote.hidden = list.length < max;
        }

        addBtn.addEventListener('click', function () {
            if (rows().length >= max) return;
            var html = tpl.innerHTML.replace(/__i__/g, String(nextIndex++)).replace(/__n__/g, String(rows().length + 1));
            people.insertAdjacentHTML('beforeend', html);
            refresh();
            var added = rows().pop();
            added.querySelector('input').focus();
        });

        people.addEventListener('click', function (e) {
            var btn = e.target.closest('.ds-referral__remove');
            if (!btn) return;
            var row  = btn.closest('.ds-referral__person');
            var list = rows();
            var at   = list.indexOf(row);
            row.remove();
            refresh();
            // Keep keyboard focus nearby: the row that took its place, else the add button.
            var next = rows()[Math.min(at, rows().length - 1)];
            (next ? next.querySelector('input') : addBtn).focus();
        });

        function fieldFor(name) {
            return form.querySelector('.ds-lead__field[data-name="' + name + '"]');
        }

        function setInvalid(field, invalid, message) {
            if (!field) return;
            var input = field.querySelector('input, textarea');
            var error = field.querySelector('.ds-survey__error');
            if (!error.hasAttribute('data-default')) error.setAttribute('data-default', error.textContent);
            error.textContent = message || error.getAttribute('data-default');
            field.classList.toggle('has-error', invalid);
            error.hidden = !invalid;
            if (invalid) input.setAttribute('aria-invalid', 'true');
            else input.removeAttribute('aria-invalid');
        }

        function focusFirstError() {
            var first = form.querySelector('.ds-lead__field.has-error input, .ds-lead__field.has-error textarea');
            if (first) first.focus();
        }

        function val(field) {
            return field.querySelector('input, textarea').value.trim();
        }

        function validate() {
            var ok = true;
            function check(field, bad, message) {
                setInvalid(field, bad, message);
                if (bad) ok = false;
            }
            var myEmail = val(fieldFor('referrer_email')).toLowerCase();
            var myPhone = val(fieldFor('referrer_phone'));
            check(fieldFor('referrer_name'), val(fieldFor('referrer_name')) === '');
            check(fieldFor('referrer_email'), !emailRe.test(myEmail));
            check(fieldFor('referrer_phone'), myPhone !== '' && myPhone.replace(/\D/g, '').length < 7);

            var seen = {};
            rows().forEach(function (row) {
                var get = function (key) { return row.querySelector('.ds-lead__field[data-key="' + key + '"]'); };
                var email = val(get('email')).toLowerCase();
                var phone = val(get('phone'));
                var emailMsg = !emailRe.test(email) ? null
                    : email === myEmail ? "You can't refer yourself."
                    : seen[email] ? "You've already listed this person." : '';
                check(get('name'), val(get('name')) === '');
                check(get('email'), emailMsg !== '', emailMsg);
                check(get('phone'), phone !== '' && phone.replace(/\D/g, '').length < 7);
                if (email) seen[email] = true;
            });
            focusFirstError();
            return ok;
        }

        function fail(message) {
            submitBtn.disabled = false;
            submitBtn.textContent = btnLabel;
            formError.textContent = message || "Sorry, something went wrong on our end. Please try again, or call or email us.";
            formError.hidden = false;
            if (!form.querySelector('.ds-lead__field.has-error')) formError.scrollIntoView({ block: 'center', behavior: reduceMotion ? 'auto' : 'smooth' });
        }

        form.addEventListener('input', function (e) {
            var field = e.target.closest('.ds-lead__field');
            if (field && field.classList.contains('has-error')) setInvalid(field, false);
        });

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            formError.hidden = true;
            if (!validate()) return;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Sending…';

            var data = new FormData(form);
            data.set('ds_ajax', '1');
            data.set('page_url', window.location.href);

            fetch(endpoint, { method: 'POST', body: data, credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (res) {
                    if (!res.success) throw res;
                    form.hidden = true;
                    success.hidden = false;
                    success.focus();
                    var top = wrap.getBoundingClientRect().top + window.pageYOffset - 120;
                    window.scrollTo({ top: top, behavior: reduceMotion ? 'auto' : 'smooth' });
                })
                .catch(function (err) {
                    var errors = err && err.data && err.data.errors;
                    if (errors) {
                        Object.keys(errors).forEach(function (name) { setInvalid(fieldFor(name), true, errors[name]); });
                        focusFirstError();
                    }
                    fail(err && err.data && err.data.message);
                });
        });

        refresh();
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(function (a) {
        a.addEventListener('click', function (e) {
            var t = document.querySelector(this.getAttribute('href'));
            if (t) {
                e.preventDefault();
                var off = header ? header.offsetHeight + 20 : 100;
                window.scrollTo({ top: t.getBoundingClientRect().top + window.pageYOffset - off, behavior: reduceMotion ? 'auto' : 'smooth' });
                // Move keyboard focus with the scroll (skip link, in-page nav).
                if (!t.matches('a, button, input, select, textarea, [tabindex]')) t.setAttribute('tabindex', '-1');
                t.focus({ preventScroll: true });
            }
        });
    });

    // Podcast & Video Feed — swap a YouTube thumbnail for the player on click
    document.querySelectorAll('.ds-video-card__play[data-video-id]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var id = this.getAttribute('data-video-id');
            if (!/^[A-Za-z0-9_-]{6,}$/.test(id)) return;
            var media = this.closest('.ds-video-card__media');
            var iframe = document.createElement('iframe');
            iframe.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(id) + '?autoplay=1&rel=0&playsinline=1';
            iframe.title = this.getAttribute('aria-label') || 'YouTube video';
            iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen');
            iframe.setAttribute('allowfullscreen', '');
            media.replaceChild(iframe, this);
            iframe.focus();
        });
    });

    // Audience journeys (AEC / Home Services) — see inc/audiences.php
    // The pick lives on <html data-audience="…">; CSS hides the other
    // industry's sections. The head script applied any stored pick before
    // first paint; this handles clicks, persistence, URL params and analytics.
    (function () {
        var cfg   = window.dsAudienceConfig || {};
        var KEY   = cfg.storageKey || 'ds_audience';
        var PARAM = cfg.param || 'industry';
        var VALID = ['aec', 'home_services'];
        var root  = document.documentElement;

        function current() { return root.getAttribute('data-audience') || ''; }

        function persist(value) {
            try {
                if (value) localStorage.setItem(KEY, value); else localStorage.removeItem(KEY);
            } catch (e) {}
            // Mirror to a first-party cookie for server-side tools (1 year).
            var expires = value ? 'max-age=31536000' : 'max-age=0';
            document.cookie = KEY + '=' + (value || '') + '; path=/; SameSite=Lax; ' + expires;
        }

        function syncButtons() {
            var value = current();
            document.querySelectorAll('[data-audience-set]').forEach(function (btn) {
                var on = btn.getAttribute('data-audience-set') === value;
                btn.classList.toggle('is-active', on);
                btn.setAttribute('aria-pressed', on ? 'true' : 'false');
            });
            root.classList.toggle('ds-audience-picked', !!value);
        }

        // Fill any same-origin form field that wants the audience
        // (e.g. a hidden input named "audience" or data-audience-field).
        function syncForms() {
            var value = current();
            document.querySelectorAll('input[name="audience"], input[name="industry"], [data-audience-field]').forEach(function (input) {
                input.value = value;
            });
        }

        function track(value, source) {
            window.dataLayer = window.dataLayer || [];
            window.dataLayer.push({ event: 'audience_selected', audience: value || 'all', audience_source: source || 'click' });
        }

        function apply(value, opts) {
            opts = opts || {};
            if (value && VALID.indexOf(value) === -1) return;
            if (value) root.setAttribute('data-audience', value); else root.removeAttribute('data-audience');
            persist(value);
            syncButtons();
            syncForms();
            if (!opts.silent) track(value, opts.source);
            document.dispatchEvent(new CustomEvent('ds:audience', { detail: { audience: value || '' } }));
        }

        // Bring the first newly-revealed section into view so the change is obvious.
        function revealFrom(trigger, value) {
            var section = trigger.closest('.ds-section, .ds-hero');
            if (!section) return;
            var next = section.nextElementSibling;
            while (next) {
                var tagged = next.getAttribute('data-audience');
                if (!tagged || tagged === value) break;
                next = next.nextElementSibling;
            }
            if (next && next !== section) {
                var header = document.getElementById('ds-header');
                var offset = header ? header.getBoundingClientRect().height : 0;
                var top = next.getBoundingClientRect().top + window.scrollY - offset;
                window.scrollTo({ top: top, behavior: 'smooth' });
            }
        }

        document.addEventListener('click', function (e) {
            var clear = e.target.closest('[data-audience-clear]');
            if (clear) {
                e.preventDefault();
                apply('', { source: 'clear' });
                return;
            }
            var btn = e.target.closest('[data-audience-set]');
            if (!btn) return;
            var value = btn.getAttribute('data-audience-set');
            var mode  = btn.getAttribute('data-audience-on-select') || 'reveal';
            var isLink = btn.tagName === 'A' && btn.getAttribute('href');

            if (mode === 'navigate' && isLink) {
                // Save first, then let the browser follow the link.
                apply(value, { source: 'navigate' });
                return;
            }
            e.preventDefault();
            var changed = value !== current();
            apply(value, { source: 'reveal', silent: !changed });
            if (changed) revealFrom(btn, value);
        });

        // A pick arriving via ?industry=… was applied by the head script; record it.
        var fromUrl = new RegExp('[?&]' + PARAM + '=([^&#]+)').exec(location.search);
        if (fromUrl && current()) {
            persist(current());
            track(current(), 'url');
        }
        syncButtons();
        syncForms();
        window.dsAudience = { get: current, set: function (v) { apply(v, { source: 'api' }); }, clear: function () { apply('', { source: 'api' }); } };
    })();

    // Code Snippet: copy button
    document.querySelectorAll('[data-ds-copy-code]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var code = btn.closest('.ds-code-snippet').querySelector('pre code');
            var label = btn.querySelector('.ds-code-snippet__copy-label');
            var text = code ? code.textContent : '';
            var done = function () {
                btn.classList.add('is-copied');
                if (label) label.textContent = 'Copied!';
                clearTimeout(btn._dsCopyTimer);
                btn._dsCopyTimer = setTimeout(function () {
                    btn.classList.remove('is-copied');
                    if (label) label.textContent = 'Copy';
                }, 2000);
            };
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(done);
                return;
            }
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.setAttribute('readonly', '');
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            try { if (document.execCommand('copy')) done(); } catch (e) {}
            document.body.removeChild(ta);
        });
    });

})();
